//import java.rmi.*;
import java.rmi.registry.LocateRegistry ;
import java.rmi.registry.Registry ;

public class CalculatorServer {

	public static void main ( String [ ] args ) {
		// Security manager is disabled
		System.setProperty("java.security.policy", "./security.policy");
		//method sets the system property indicated by the specified key
		try {	
			// Enable the security manager			
			System.setSecurityManager(new SecurityManager());
			CalculatorImpl stub = new CalculatorImpl(); //create remote object
			Registry registry = LocateRegistry.getRegistry (2019);
			//Returns a reference to the the remote object Registry 
						//for the local host on the specified port.
			registry.rebind("Calculator", stub );// Bind the object to the RMI registry
			System.out.println("server is ready");
		} catch ( Exception e) {
			e.printStackTrace();
			}
	}	  
}


