//import java.rmi.*;
import java.rmi.Remote;
import java.rmi.RemoteException;

//Definition of the access interface to the remote addressable object
public interface Calculator extends Remote {
	public  int calculator(String str) throws RemoteException; 
} 
