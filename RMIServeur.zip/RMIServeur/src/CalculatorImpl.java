//import java.rmi.*;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.StringTokenizer;

//Code that will actually perform the operations defined in the interface
public class CalculatorImpl extends UnicastRemoteObject implements Calculator { 
	public CalculatorImpl()  throws RemoteException {  } ;
	
	public  int calculator(String str)   throws RemoteException {
		int answer=0; //initialize result;
		StringTokenizer st = new StringTokenizer(str); //break equation to operand and operation  
        int int1 = Integer.parseInt(st.nextToken()); //string to integer
        String operation = st.nextToken(); 
        int int2 = Integer.parseInt(st.nextToken()); //string to integer
        
        if(int1>=0 && int2>=0) { 
        	switch (operation) {
			case "+": answer = int1 + int2;
				break;
			case "-": answer = int1 - int2;
			    break;
			case "*": answer = int1 * int2;
                break;
			case "/": if(int2==0) {System.out.println("Error: division by zero");return -1;}
			          else answer = int1 / int2;
                break;
			default: System.out.println("WRONG operation"); 
			    return -1; //when operation is different from [+-*/] 
			}
        	if(answer>=0) return answer;
            else System.out.println("Error: negative result");
        }else System.out.println("Please,enter positive integer");
        
        return -1;
   }
} 