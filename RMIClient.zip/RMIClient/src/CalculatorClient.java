//import java.rmi.*;
import java.rmi.registry.LocateRegistry ;
import java.rmi.registry.Registry ;
import java.util.Scanner;

public class CalculatorClient {
	public static void main ( String args []) {
		// Security manager is disabled
		System.setProperty("java.security.policy", "./secclient.policy");
	    Scanner sc = new Scanner(System.in); 
		try {
	        System.out.println("Enter the equation in the form: 'operand operator operand' WITH SPACE"); 
			// Enable the security manager			
	        System.setSecurityManager(new SecurityManager());
	      //LocateRegistry is used to create a remote object registry 
	           //that accepts calls on a specific port.
	        Registry registry = LocateRegistry.getRegistry (2019);
			Calculator c = (Calculator) registry.lookup ("Calculator");
			//registry.lookup will find the remote object by its name and return a remote reference.
	        String inp =sc.nextLine(); //returns the rest of the current line
			System.out.println ( "Answer : "+ c.calculator(inp));
	
		} catch ( Exception e) {
			e.printStackTrace();
			}
	}
}
